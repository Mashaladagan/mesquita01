package org.kotlinlang.play

fun main(){
    println("digite o numero:")
    var print : Int = 0
    var n1 : Int = 0
    var n2 : Int = 1
    var i : Int = 0
    var fim : Int = readln().toInt()
    if (fim < 1)
    {
        println(0)
    }
    else
    {
        while (i < fim) {
            print = n1 + n2
            n1 = n2
            n2 = print
            println(print)
            i++
        }
    }
}